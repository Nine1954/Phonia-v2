package com.phobia;

import java.util.function.Supplier;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

@Mod(Phobia.MODID)
public class Phobia {
    public static final String MODID = "phobia";

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MODID);

    // Per-player data (sanity, stamina). Survives death.
    public static final Supplier<AttachmentType<PlayerStats>> STATS = ATTACHMENTS.register("stats",
            () -> AttachmentType.builder(() -> new PlayerStats())
                    .serialize(PlayerStats.CODEC)
                    .copyOnDeath()
                    .build());

    public Phobia(IEventBus modBus, ModContainer container) {
        ATTACHMENTS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        modBus.addListener(Net::register);
        container.registerConfig(ModConfig.Type.SERVER, PhobiaConfig.SPEC);
    }
}
